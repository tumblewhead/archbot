#!/usr/bin/env python3
"""Apply C-002 Option B authority decision without clobbering live PC artifacts.

Requires PyYAML (already a dependency of the prototype).
Run --check first, then --apply. All updates are planned before writing.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
from pathlib import Path
import shutil
import sys
import yaml

PACKAGE = Path(__file__).resolve().parent
BASE = PACKAGE / 'baseline'
PAYLOAD = PACKAGE / 'payload'

SEED = [
    'process/policies/AP_SELECTION_v2.yaml',
    'process/relationships.yaml', 'process/views.yaml', 'process/workflow.yaml',
    'process/examples/ap-assessment-template.yaml',
    'tools/attach_process_spine.py',
    'agents/evaluation-agent.md', 'agents/evidence-planning-agent.md',
    'prompts/12-ae003-provisional.md', 'prompts/13-vo-reconciliation.md',
    'knowledge/architecture/AS-001/verification_plan.md',
    'knowledge/architecture/AS-001/verification/VO-001.md',
    'knowledge/architecture/AS-001/verification/VO-002.md',
    'knowledge/architecture/AS-001/verification/VO-003.md',
    'knowledge/architecture/AS-001/verification/VO-004.md',
    'knowledge/architecture/AS-001/verification/VO-005.md',
    'knowledge/architecture/AS-001/verification/VO-006.md',
    'README_PROCESS_V2.md',
]
MANAGED_CODE = ['tools/stage_gate.py', 'tests/test_stage_gate.py']
ADD = [
    'process/decisions/C-002-approval.md',
    'knowledge/architecture/AS-001/decisions/C-002-SCOPE-001.md',
    'docs/AE003_GATE.md', 'prompts/14-ap-envelopes.md',
    'prompts/15-ae003-controlled.md',
    'process/examples/ap-memory-envelope-template.yaml',
]


def read_yaml_blob(blob, location):
    try:
        value = yaml.safe_load(blob)
    except yaml.YAMLError as exc:
        raise ValueError(f'{location}: YAML error: {exc}') from exc
    if not isinstance(value, dict):
        raise ValueError(f'{location}: expected YAML mapping')
    return value


def dump_yaml(value):
    return yaml.safe_dump(value, sort_keys=False, allow_unicode=True).encode('utf-8')


def text(blob):
    return blob.decode('utf-8')


def insert_link(blob, label, target):
    raw = text(blob)
    if not raw.startswith('---\n'):
        raise ValueError(f'{label}: expected YAML frontmatter')
    end = raw.find('\n---\n', 4)
    if end < 0:
        raise ValueError(f'{label}: frontmatter terminator missing')
    head = read_yaml_blob(raw[4:end].encode(), label)
    relations = head.setdefault('relations', [])
    if not isinstance(relations, list):
        raise ValueError(f'{label}: relations not a list')
    if not any(isinstance(r, dict) and r.get('target') == target for r in relations):
        relations.append({'kind':'specifies','target':target})
    return b'---\n' + dump_yaml(head) + b'---\n' + raw[end+5:].encode()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--check', action='store_true', help='report intended changes; write nothing')
    group.add_argument('--apply', action='store_true', help='apply after preflight; back up replaced files')
    ap.add_argument('--root', type=Path, default=Path.cwd(), help='local PC repository root')
    ap.add_argument('--backup-dir', type=Path, help='destination outside repo for backups')
    args = ap.parse_args()
    root = args.root.resolve()
    if not (root/'AGENTS.md').is_file() or not (root/'knowledge/architecture/AS-001/spine.md').is_file():
        ap.error('--root must be a Progressive Concretization checkout with AGENTS.md and AS-001 spine')
    pending = {}
    notes = []
    errors = []

    def existing_or_seed(rel):
        dst = root / rel
        if rel in pending:
            return pending[rel]
        if dst.exists():
            return dst.read_bytes()
        seed = BASE/rel
        if not seed.is_file():
            raise ValueError(f'Missing baseline source: {rel}')
        blob = seed.read_bytes()
        pending[rel] = blob
        return blob

    def plan(rel, blob):
        dst = root / rel
        if not dst.exists() or dst.read_bytes() != blob:
            pending[rel] = blob

    # Independent files: create only; never replace local docs or history.
    for rel in SEED:
        if not (root/rel).exists():
            plan(rel, (BASE/rel).read_bytes())
        else:
            notes.append(f'PRESERVE user file: {rel}')
    for rel in ADD:
        desired = (PAYLOAD/rel).read_bytes()
        dst = root/rel
        if dst.exists() and dst.read_bytes() != desired:
            errors.append(f'CONFLICT: locally modified controlled/new file: {rel}')
        else:
            plan(rel, desired)

    # Update gate script and its unit tests only from a known parent version.
    for rel in MANAGED_CODE:
        dst = root/rel
        desired = (PAYLOAD/rel).read_bytes()
        prior = (BASE/rel).read_bytes()
        if dst.exists() and dst.read_bytes() not in (prior, desired):
            errors.append(f'CONFLICT: gate code differs from known v2 baseline: {rel}; review manually')
        else:
            plan(rel, desired)

    # Apply scope-specific selection policy metadata without changing F-001.
    rel = 'process/policies/AP_SELECTION_v2.yaml'
    policy = read_yaml_blob(existing_or_seed(rel), rel)
    approved_policy = read_yaml_blob((PAYLOAD/rel).read_bytes(), 'approved selection policy')
    if policy.get('id') != 'AP-SELECT-002' or policy.get('selection_kind') != 'PROVISIONAL_COMMITMENT':
        errors.append('CONFLICT: AP selection policy identity or semantics differ')
    for key in ('approved_scope_refs', 'ap_memory_envelope'):
        if key in policy and policy[key] != approved_policy[key]:
            errors.append(f'CONFLICT: existing {key} differs from controlled Option B scope')
        policy[key] = approved_policy[key]
    plan(rel, dump_yaml(policy))

    # Scope decision: preserve any additional metadata, but refuse conflicting approval.
    rel = 'process/decisions/C-002-scope.yaml'
    live = read_yaml_blob(existing_or_seed(rel), rel)
    canonical = read_yaml_blob((PAYLOAD/rel).read_bytes(), 'payload scope')
    if live.get('id') != 'C-002-SCOPE-001' or live.get('requirement') != 'C-002':
        errors.append('CONFLICT: C-002 scope decision has unexpected identity')
    if live.get('status') == 'approved':
        if live.get('chosen') != 'detector_charged_sram':
            errors.append('CONFLICT: another C-002 scope was already approved')
        if live.get('approved_by') not in (None, 'user:engineering_authority'):
            errors.append('CONFLICT: approved scope has different authority; review manually')
    elif live.get('status') != 'pending_authority':
        errors.append(f'CONFLICT: unexpected C-002 status {live.get("status")!r}')
    else:
        if live.get('chosen') not in (None, 'detector_charged_sram'):
            errors.append('CONFLICT: pending authority carries another selection')
    for key in ('status','chosen','approved_by','approval_evidence','approval_date_local','accounting'):
        live[key] = canonical[key]
    plan(rel, dump_yaml(live))

    rel = 'process/ledgers/ad_ledger.yaml'
    debts = read_yaml_blob(existing_or_seed(rel), rel)
    matches = [x for x in debts.get('items',[]) if x.get('id')=='AD-001']
    if len(matches)!=1:
        errors.append('CONFLICT: expected exactly one AD-001 scope debt')
    else:
        debt = matches[0]
        if debt.get('state') not in ('blocking','resolved'):
            errors.append('CONFLICT: AD-001 scope debt has unexpected state')
        debt.update(state='resolved', resolved_by='C-002-SCOPE-001', resolution_evidence='process/decisions/C-002-approval.md')
        plan(rel, dump_yaml(debts))

    rel = 'process/ledgers/vo_ledger.yaml'
    vo = read_yaml_blob(existing_or_seed(rel), rel)
    matches = [x for x in vo.get('obligations',[]) if x.get('id')=='VO-002' and x.get('requirement')=='C-002']
    if len(matches)!=1:
        errors.append('CONFLICT: expected exactly one VO-002/C-002')
    else:
        # Do not modify the VO's discharge state.
        matches[0].update(accounting_scope='C-002-SCOPE-001',
            ap_stage_requirement='Credible categorized charged-SRAM envelope, attribution and positive margin; final implementation verification remains due.')
        plan(rel, dump_yaml(vo))

    # Link the approved OKF decision from both authoritative spines.
    link = '/architecture/AS-001/decisions/C-002-SCOPE-001.md'
    for rel in ('knowledge/architecture/AS-001/spine.md',
                'knowledge/architecture/AS-001/decisions/PC-002-spine.md'):
        try:
            data = existing_or_seed(rel) if rel.endswith('PC-002-spine.md') else (root/rel).read_bytes()
            plan(rel, insert_link(data, rel, link))
        except (OSError, ValueError) as exc:
            errors.append(f'CONFLICT: {exc}')

    # Enforce a controlled backup strategy: backups live outside Git checkout.
    backup = args.backup_dir.resolve() if args.backup_dir else (root.parent/'pc-option-b-backups'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')).resolve()
    if root == backup or root in backup.parents:
        errors.append('Backup directory cannot be inside project root')
    print(f'ROOT: {root}\nMODE: {"CHECK" if args.check else "APPLY"}')
    for rel in sorted(pending):
        action = 'UPDATE' if (root/rel).exists() else 'CREATE'
        print(f'{action}: {rel}')
    for note in notes:
        print(note)
    for error in errors:
        print(error, file=sys.stderr)
    if errors:
        print(f'ABORT: {len(errors)} conflict(s), nothing written', file=sys.stderr)
        return 2
    if args.check:
        print(f'PRECHECK PASS: {len(pending)} change(s) would be applied; no files modified.')
        return 0
    # Backups first, then write changes.
    updates = [rel for rel in pending if (root/rel).exists()]
    if updates:
        for rel in updates:
            dst=backup/rel
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(root/rel,dst)
        print(f'BACKUPS: {backup}')
    for rel, content in pending.items():
        dst = root/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        dst.write_bytes(content)
    print(f'APPLIED: {len(pending)} controlled changes. AS, F, theory, AGENTS, historical runs are untouched.')
    print('NEXT: python tools/pc.py check --fast && python -m unittest discover -s tests -v')
    print('NEXT: python tools/stage_gate.py inspect  # VO-001 may still block AE-003')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
