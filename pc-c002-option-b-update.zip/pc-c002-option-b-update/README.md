# C-002 Option B authority and AE-003 gate overlay

**Project:** Progressive Concretization (Codex pilot).  **Decision:** `C-002-SCOPE-001`.

This is an **additive, conservative installer** for a local checkout that may have
advanced beyond the process-v2 reference snapshot. It preserves `AGENTS.md`,
`theory_of_operation.md`, AS-001, F-001, all historical evaluations and proofs,
existing Codex telemetry, and independently modified agent files.

## Engineering authority

The authority explicitly approved **Option B: detector-attributable SRAM**.
C-002 still limits detector-charged SRAM to **2048 bytes**. The approval source
is quoted in `payload/process/decisions/C-002-approval.md`.

The decision DOES NOT approve any SRAM budget, AP, F-001 tradeoff, firmware, or
final VO discharge. Check that the transcribed approval matches your record.

## Apply from the repository root

```
unzip pc-c002-option-b-update.zip -d /tmp
python /tmp/pc-c002-option-b-update/apply.py --root "$PWD" --check
python /tmp/pc-c002-option-b-update/apply.py --root "$PWD" --apply
python tools/pc.py check --fast
python -m unittest discover -s tests -v
python tools/stage_gate.py inspect
```

Commit or back up your local checkout before applying. The script also backs
up every overwritten file outside the checkout in `../pc-option-b-backups/`.
On any conflict the installer stops **before writing anything**.

It adds missing essential process-v2 files, preserves any existing unknown
process files, updates only the controlled C-002 decision and AD-001/VO-002
ledger entries, applies the known stage checker and its tests, and adds
an OKF decision concept linked from the existing AS and process spines.
It will not overwrite diverged checker code; review that conflict manually.

## AE-003 process, in order

1. `VO-001` is still open and due at AS. Run `prompts/13-vo-reconciliation.md`
   with `verification-agent`, obtain accepted evidence and update the VO ledger
   via an independently authorized controlled action. No auto-discharge.
2. Prepare **both** candidates' credible SRAM envelopes, with
   `prompts/14-ap-envelopes.md`, preferably with `evidence-planning-agent`.
   Budget allocations are assumptions/commitments, **not** measured SRAM use.
3. Use `prompts/15-ae003-controlled.md` with `evaluation-agent`. It must
   produce candidate assessments and run the deterministic gate checker.
4. If F-001's three projected dimensions do not determine a defensible choice,
   seek *separate* stakeholder authorization of a provisional tradeoff with AD.
   **Option B scope approval is not tradeoff approval.**
5. Independent AP selection (if authorized) permits CON-first decomposition.
   All VOs and accepted AD follow the design downstream. Final acceptance
   still requires the complete firmware/target evidence.

```
python tools/telemetry.py run --role verification-agent --prompt prompts/13-vo-reconciliation.md
python tools/telemetry.py export --run latest

python tools/telemetry.py run --role evidence-planning-agent --prompt prompts/14-ap-envelopes.md
python tools/telemetry.py export --run latest

python tools/telemetry.py run --role evaluation-agent --prompt prompts/15-ae003-controlled.md
python tools/telemetry.py export --run latest
```

Note that `process/examples/ap-memory-envelope-template.yaml` is **not an
approved envelope**; it contains deliberately unsupported illustrative budgets.

## Gate outcomes

`tools/stage_gate.py evaluate --assessment <candidate.yaml>` checks whether
required evidence fields, memory categories, charging assumptions, positive
margin, VOs, and authority references are complete. PASS from that script
means `ELIGIBLE_FOR_INDEPENDENT_REVIEW`, not `PROVISIONALLY_SELECTED`.

A scope-only approval cannot unblock a missing VO-001 acceptance, an unfounded
memory model, or an unapproved F-001 tradeoff.

## Offline test results

Tested on the process-v2 reference checkout and on a baseline starter missing
v2 files. The process-v2 reconciliation passed 28 unit tests with zero graph
errors; second application was idempotent (zero changes). An already-approved
conflicting Option A record was rejected before any modification. Live-user
checkout reconciliation remains to be executed locally.
